<?php
include ('include/header.php');
?>

</head>
<body>   
 <?php
include ('include/sidebar.php');
?>


    <div class="pageheader">
      <h2><i class="fa fa-home"></i> Dashboard </h2>
    </div>

    <div class="contentpanel">

      <div class="row">
      </div>

      
      
      
    </div><!-- contentpanel -->

  </div><!-- mainpanel -->

  
</section>


<?php
 include ('include/footer.php');
 ?>
 	
</body>
</html>